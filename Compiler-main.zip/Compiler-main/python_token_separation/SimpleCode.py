print ("Some Name from BTech")
f = 10
for count in range(1,11): 
    e = f * count
    print(f, "x", count, "=", e)
